module.exports = {
    user : 'java'
    ,password : 'oracle'
    ,connectString : 'localhost:1521/XE'
}